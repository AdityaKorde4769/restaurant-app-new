const foods = [
{ id: 1, name: "Butter Chicken", price: 299, image:
"https://source.unsplash.com/400x300/?butter-chicken" },
{ id: 2, name: "Paneer Tikka", price: 249, image:
"https://source.unsplash.com/400x300/?paneer-tikka" },
{ id: 3, name: "Biryani", price: 199, image: "https://source.unsplash.com/400x300/?biryani" },
{ id: 4, name: "Masala Dosa", price: 149, image: "https://source.unsplash.com/400x300/?dosa"
},
{ id: 5, name: "Chole Bhature", price: 179, image:
"https://source.unsplash.com/400x300/?chole-bhature" }
];
{
  id: 6,
  name: "Veg Fried Rice",
  price: 159,
  image: "https://source.unsplash.com/400x300/?fried-rice"
},
{
  id: 7,
  name: "Chicken Curry",
  price: 279,
  image: "https://source.unsplash.com/400x300/?chicken-curry"
},
{
  id: 8,
  name: "Gulab Jamun",
  price: 99,
  image: "https://source.unsplash.com/400x300/?gulab-jamun"
}
module.exports = foods;
