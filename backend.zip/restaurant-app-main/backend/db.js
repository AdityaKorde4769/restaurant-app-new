const mysql = require("mysql2");
const db = mysql.createConnection({
host: "restaurant-db.cqbym6u20r19.us-east-1.rds.amazonaws.com", // e.g. mydb.xxxxxx.ap-south-1.rds.amazonaws.com
user: "admin",
password: "Password",
database: "restaurant",
});
db.connect((err) => {
if (err) {
console.error("DB connection failed:", err);
} else {
console.log("MySQL Connected ✅");
}
});
module.exports = db;
