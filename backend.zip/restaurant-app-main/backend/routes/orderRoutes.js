const express = require("express");
const router = express.Router();
const db = require("../db");

router.post("/", (req, res) => {
  const { user_id, cart, total } = req.body;

  // 1️⃣ Insert into orders
  db.query(
    "INSERT INTO orders (user_id, total) VALUES (?, ?)",
    [user_id, total],
    (err, result) => {
      if (err) return res.send(err);

      const orderId = result.insertId;

      // 2️⃣ Insert each item into order_items
      cart.forEach(item => {
        db.query(
          "INSERT INTO order_items (order_id, food_id, quantity) VALUES (?, ?, ?)",
          [orderId, item.id, item.qty]
        );
      });

      res.send("Order placed successfully 🎉");
    }
  );
});


// 📜 GET ORDER HISTORY
router.get("/:userId", (req, res) => {
  const userId = req.params.userId;

  const query = `
    SELECT 
      o.id AS order_id,
      o.total,
      o.created_at,
      COALESCE(oi.name, f.name) AS food_name,
      oi.quantity
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    LEFT JOIN foods f ON oi.food_id = f.id
    WHERE o.user_id = ?
    ORDER BY o.id DESC
  `;

  db.query(query, [userId], (err, results) => {
    if (err) return res.send(err);

    res.json(results);
  });
});
module.exports = router;
