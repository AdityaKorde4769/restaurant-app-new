const express = require("express");
const db = require("./db");
const cors = require("cors");
const app = express();
app.use(cors());
app.use(express.json());
const foodRoutes = require("./routes/foodRoutes");
const orderRoutes = require("./routes/orderRoutes");
app.use("/api/foods", foodRoutes);
app.use("/api/order", orderRoutes);
app.get("/", (req, res) => {
res.send("Restaurant API Running 🚀");
});
const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
// REGISTER
app.post("/api/register", (req, res) => {
  const { name, email, password } = req.body;

  db.query(
    "INSERT INTO users (name,email,password) VALUES (?,?,?)",
    [name, email, password],
    (err, result) => {
      if (err) return res.send(err);
      res.send("User Registered");
    }
  );
});

// LOGIN
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;

  db.query(
    "SELECT * FROM users WHERE email=? AND password=?",
    [email, password],
    (err, result) => {
      if (err) return res.send(err);
      if (result.length > 0) res.json(result[0]);
      else res.send("Invalid credentials");
    }
  );
});

// PLACE ORDER
app.post("/api/order", (req, res) => {
  const { user_id, cart, total } = req.body;

  db.query(
    "INSERT INTO orders (user_id,total) VALUES (?,?)",
    [user_id, total],
    (err, orderResult) => {
      if (err) return res.send(err);

      const orderId = orderResult.insertId;

      cart.forEach(item => {
        db.query(
          "INSERT INTO order_items (order_id,food_id,quantity) VALUES (?,?,?)",
          [orderId, item.id, item.qty]
        );
      });

      res.send("Order placed");
    }
  );
});

app.post("/api/register", (req, res) => {
  const { name, email, password } = req.body;

  db.query(
    "INSERT INTO users (name,email,password) VALUES (?,?,?)",
    [name, email, password],
    (err, result) => {
      if (err) return res.send(err);
      res.send("User Registered");
    }
  );
});
